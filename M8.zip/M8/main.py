from flask import Flask, render_template,request, redirect
from flask_sqlalchemy import SQLAlchemy


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///diary.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app )

class Global_plus_temp(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    h1 = db.Column(db.Text, nullable=False)
    h2 = db.Column(db.Text, nullable=False)
    h3 = db.Column(db.Text, nullable=False)
    h4 = db.Column(db.Text, nullable=False)
    h5 = db.Column(db.Text, nullable=False)
    h6 = db.Column(db.Text, nullable=False)
    p = db.Column(db.Text, nullable=False)
    img = db.Column(db.Text, nullable=False)
    tegs_pos = db.Column(db.Text, nullable=False)


@app.route('/')
def index():
    tegs = Global_plus_temp.query.order_by(Global_plus_temp.id).all()
    tegs = tegs[0]
    h1 = tegs.h1.split('@')
    h2 = tegs.h2.split('@')
    h3 = tegs.h3.split('@')
    h4 = tegs.h4.split('@')
    h5 = tegs.h5.split('@')
    h6 = tegs.h6.split('@')
    p = tegs.p.split('@')
    img = tegs.img.split('~')
    tegs_pos = tegs.tegs_pos.split('|')
    for i in range(len(tegs_pos)):
        tegs_pos[i] = tegs_pos[i].split(',')
    for i in range(len(tegs_pos)):
        for j in range(len(tegs_pos[i])):
            tegs_pos[i][j] = tegs_pos[i][j].split('#')
            tegs_pos[i][j][0] = int(tegs_pos[i][j][0])
    print(tegs_pos)
    count_slides = len(tegs_pos)
    count_tegs = []
    for slide in tegs_pos:
        count_tegs.append(len(slide))
    count_img = len(img)
    count_p = len(p)
    return render_template('index.html',h1=h1,h2=h2,h3=h3,h4=h4,h5=h5,h6=h6,p=p,img=img,tegs_pos=tegs_pos,count_slides=count_slides,count_tegs=count_tegs,count_img=count_img,count_p=count_p)

if __name__ == "__main__":
    app.run(debug=True)