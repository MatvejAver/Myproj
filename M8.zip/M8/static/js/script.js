$(document).ready(function () {
    $('.slider').bxSlider({
        pagerCustom: '.slider-nav',
        infiniteLoop: true,
        hideControlOnEnd: true,
        captions: true, 
        nextText: '',
        prevText: '',
        easing: 'jswing',
    });
});